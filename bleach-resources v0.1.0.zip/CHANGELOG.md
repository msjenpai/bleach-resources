# Bleach Resources Changelog

## v0.1.0 - Initial Public Playtest

### Shinigami

- Added complete Shinigami class progression through level 20.
- Added Shinigami class advancements.
- Added Fighting Style support.
- Added Zankensoki progression.
- Added Reiraku.
- Added Reiatsu support.
- Added Air Walk.
- Added Shikai.
- Added Spirit Materialization.
- Added Bankai.
- Added Senkaimon.
- Added Mastered Art.
- Added Mastered Zanpakutō.
- Added Ningen-kai no Gādian.

### Combat Arts

- Added Zanjutsu content.
- Added Hakuda content.
- Added Hoho content.
- Added Shunkō content.
- Added supporting technique automation where appropriate.

### Kidō

- Added Kidō compendium content.
- Added Kidō level filtering during Zankensoki advancement.
- Added automatic Actor Reiryoku linking for Kidō consumption.
- Added Kidō Efficiency support.
- Added Kidō Mastery support.
- Added combined Reiryoku-cost reduction handling.
- Reiryoku costs cannot be reduced below 1.

### Resources

- Added character-sheet Reiryoku display.
- Added character-sheet Stamina display.
- Added resource editing from the character sheet.
- Added universal Reiryoku framework.
- Reiryoku is no longer architecturally restricted to Shinigami.
- Added support architecture for Shinigami, Quincy, Hollow, and Fullbringer Reiryoku contributions.
- Added flat, dynamic, multiplier, and override modifier support.
- Maximum Reiryoku changes preserve current Reiryoku.

### Reiryoku Features

- Added Spirit Training Reiryoku scaling.
- Added Ningen-kai no Gādian Reiryoku increase.
- Added Infinite Reserves dynamic Reiryoku scaling.
- Added Soul King's Host Reiryoku support.
- Added Tiny General Part dynamic Reiryoku scaling.

### Mastered Art

- Added Zanjutsu Mastery support.
- Added Hakuda Mastery support.
- Added Kidō Mastery support.
- Added Hoho Mastery rules support.

### UI

- Added custom Reiryoku resource bar.
- Added custom Stamina resource bar.
- Improved D&D 5e character-sheet integration.

### Fixes

- Fixed Reiryoku synchronization loops.
- Fixed maximum Reiryoku changes incorrectly changing current Reiryoku.
- Fixed Reiryoku Item consumption references.
- Fixed new character resource initialization.
- Fixed several Advancement and resource-update race conditions.
- Fixed multiplayer testing issue caused by clients running mismatched cached module versions.

### Work in Progress

- Background Feats
- Remaining general feat categories
- Universal Reiatsu modifier architecture
- Hollow
- Quincy
- Fullbringer
- Additional automation and validation