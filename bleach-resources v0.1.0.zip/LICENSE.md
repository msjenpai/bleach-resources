# Licensing

Bleach Resources contains materials with different licensing statuses.

## Bleach Resources Source Code

Unless otherwise noted, original JavaScript, CSS, module configuration, automation code, and other original software authored specifically for Bleach Resources are made available under the MIT License.

Copyright (c) 2026 Bleach Resources contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Game Content and Third-Party Material

The MIT License above does not relicense third-party game content, names,
settings, artwork, rules text, or other intellectual property included in or
referenced by this project.

Such material remains subject to its original license or copyright.

See `ATTRIBUTION.md` and `DISCLAIMER.md`.