# Bleach Resources

**Bleach Resources** is an unofficial fan-made Foundry VTT module designed to support the **Soul Society 5e** ruleset and Bleach-inspired campaigns using the D&D 5e game system.

> ⚠️ **PLAYTEST BUILD**
>
> This module is currently in active development. Features, automation, compendium content, identifiers, and mechanics may change between versions.

## Current Version

**v0.1.0 - Playtest Alpha**

## Compatibility

This release has been developed and tested with:

- Foundry Virtual Tabletop: **v14 Build 368**
- D&D 5e System: **v6.0.5**

Other versions have not yet been validated.

## Current Playtest Scope

The primary focus of this release is the **Shinigami** class and its associated systems.

Current implementation includes:

- Shinigami class progression from levels 1-20
- Reiryoku resource system
- Stamina resource system
- Reiatsu support
- Zanpakutō progression
- Fighting Styles
- Zankensoki progression
- Zanjutsu Arts
- Hakuda Techniques
- Kidō
- Hoho
- Spiritual Expertises
- Shunkō techniques
- Shikai
- Bankai
- Spirit Materialization
- Senkaimon
- Mastered Art
- Mastered Zanpakutō
- Ningen-kai no Gādian
- Initial Background Feat support
- Character-sheet Reiryoku and Stamina displays
- Automatic Reiryoku consumption linking
- Kidō Reiryoku-cost reductions
- Several automated mastery interactions

### Universal Spiritual Systems

Reiryoku has been rebuilt as a universal resource architecture in preparation for support for:

- Shinigami
- Hollow
- Quincy
- Fullbringer

Only systems specifically listed as implemented should currently be considered playtest-ready.

## Compendiums

Bleach Resources includes compendium content for the implemented Soul Society 5e systems.

Included content currently covers areas such as:

- Kidō
- Zanjutsu
- Hakuda
- Hoho
- Spiritual Expertises
- Shinigami class features
- Related techniques and supporting features

Some categories are still under development.

## Installation

### Manifest Installation

Once a public release has been created, copy the Manifest URL from the GitHub release and paste it into:

**Foundry Setup → Add-on Modules → Install Module → Manifest URL**

Manifest URL:

`https://github.com/YOUR-USERNAME/YOUR-REPOSITORY/releases/latest/download/module.json`

### Manual Installation

1. Download the release ZIP.
2. Extract the `bleach-resources` folder into your Foundry VTT `Data/modules/` directory.
3. Restart Foundry VTT.
4. Open your D&D 5e world.
5. Open **Manage Modules**.
6. Enable **Bleach Resources**.

## Updating

All connected players should completely reload Foundry after updating Bleach Resources.

For development/playtest builds, it is strongly recommended that every connected client close and reopen Foundry after a module update.

Running different cached versions of the module across multiple connected clients may cause conflicting automation.

## Playtesting

Please read [PLAYTESTING.md](PLAYTESTING.md) before submitting bug reports.

When reporting a problem, include:

- Bleach Resources version
- Foundry version
- D&D 5e system version
- Other enabled modules
- Character level/class
- Steps needed to reproduce the problem
- Expected result
- Actual result
- Browser console errors, if any

## Known Limitations

- Development is ongoing.
- Some high-complexity mechanics require manual resolution.
- Reiatsu automation is not yet complete.
- Hollow, Quincy, and Fullbringer class implementations are not yet complete.
- Background Feats are currently being implemented.
- Some prerequisites or highly contextual abilities may require GM adjudication.

Automation will not intentionally replace source mechanics where Foundry cannot reproduce them faithfully.

## Feedback and Bug Reports

Please use the GitHub Issues page for bugs and playtest feedback.

For development discussion and support, join the Bleach Resources Discord community.

## Disclaimer

Bleach Resources is an unofficial fan project and is not affiliated with or endorsed by the creators, publishers, distributors, or rights holders of Bleach, Dungeons & Dragons, Foundry Virtual Tabletop, or the source material adapted by this project.

See [DISCLAIMER.md](DISCLAIMER.md) and [ATTRIBUTION.md](ATTRIBUTION.md) for additional information.

## License and Attribution

Source code, original project material, third-party material, and adapted game content may be subject to different licenses.

See:

- [LICENSE.md](LICENSE.md)
- [ATTRIBUTION.md](ATTRIBUTION.md)

for details.