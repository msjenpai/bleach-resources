# Attribution

Bleach Resources contains implementations and adaptations of tabletop rules and concepts originating from third-party sources.

## Soul Society 5e / Soul Society Supplement

Primary rules reference:

D&D Wiki  
https://www.dandwiki.com/

Soul Society 5e Campaign Setting and associated Soul Society Supplement pages are used as the primary mechanical reference for this project.

Relevant source pages include, but are not limited to:

- Soul Society (5e Campaign Setting)
- Shinigami (Soul Society Supplement)
- Feats (Soul Society Supplement)
- Hollow (Soul Society Supplement)
- Quincy (Soul Society Supplement)
- Fullbringer (Soul Society Supplement)
- associated Kidō, Zanjutsu, Hakuda, Hoho, feat, equipment, and supplementary pages

Bleach Resources does not claim authorship of the original rules text on these pages.

Individual source pages and revisions should be checked for their applicable license.

Where material is redistributed or adapted under a license requiring attribution, the applicable source, authorship/history, revision, and license should be preserved.

## Source Revision Tracking

For releases, it is recommended that each adapted source be recorded using a permanent revision URL when possible.

Example:

Source:
Shinigami (Soul Society Supplement)

Revision:
[PERMANENT REVISION URL]

Accessed:
[DATE]

Authors/Contributors:
See the source page history.

License:
[LICENSE DISPLAYED BY SOURCE]

## Bleach

Bleach and related characters, terminology, settings, and concepts are the intellectual property of their respective rights holders.

Bleach Resources is an unofficial fan project and is not endorsed by or affiliated with those rights holders.

## Foundry Virtual Tabletop

Foundry Virtual Tabletop is software produced by Foundry Gaming LLC.

Bleach Resources is an independently developed add-on module and is not affiliated with or endorsed by Foundry Gaming LLC.

## Dungeons & Dragons

Dungeons & Dragons and related trademarks and game material belong to their respective rights holders.

Any material reproduced under an open license remains subject to the terms of that license.