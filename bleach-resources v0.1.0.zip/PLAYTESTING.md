# Bleach Resources Playtesting Guide

Thank you for helping test Bleach Resources.

This release is an early playtest build. The purpose of public testing is to identify mechanical errors, Foundry automation issues, compatibility problems, and unclear implementation before broader development continues.

## Tested Environment

Bleach Resources v0.1.0 is currently tested against:

- Foundry VTT v14 Build 368
- D&D 5e v6.0.5

Please include your versions when reporting an issue.

## Recommended Test Environment

For the clearest results:

1. Create a fresh D&D 5e world.
2. Enable Bleach Resources.
3. Disable unrelated modules when reproducing bugs.
4. Create a new character rather than relying only on characters created by older Bleach Resources versions.
5. Test both low-level and high-level Advancement.

## Current Priority Tests

### Character Advancement

Test a Shinigami at:

- Level 1
- Level 2
- Level 5
- Level 7
- Level 11
- Level 15
- Level 18
- Level 20

Check that the appropriate features and advancements appear.

### Reiryoku

Verify that:

- Base Reiryoku increases correctly with spiritual class levels.
- Spending Reiryoku reduces current Reiryoku.
- Long Rest recovery functions.
- Increasing maximum Reiryoku does not restore current Reiryoku.
- Decreasing maximum Reiryoku does not unnecessarily consume current Reiryoku.
- Current Reiryoku is capped if the new maximum becomes lower than the current amount.

Please specifically test:

- Spirit Training
- Ningen-kai no Gādian
- Infinite Reserves
- Soul King's Host
- Soul King body-part Reiryoku modifiers

### Stamina

Verify:

- Maximum Stamina calculations.
- Spending Stamina.
- Short Rest recovery.
- Long Rest recovery.
- Constitution and proficiency changes.

### Kidō

Verify:

- Kidō level eligibility.
- Zankensoki filtering.
- Reiryoku consumption.
- Kidō Efficiency.
- Kidō Mastery.
- Combined Kidō Efficiency + Kidō Mastery.
- Minimum Reiryoku cost of 1.

### Combat Techniques

Please test:

- Zanjutsu
- Hakuda
- Hoho
- Shunkō
- Zanpakutō weapon configurations
- Fighting Styles
- Mastered Art

### Multiplayer

All connected users must reload after installing a new build.

When testing multiplayer behavior:

- Confirm every player is using the same module version.
- Fully reload every client after an update.
- Report whether a bug occurs only when multiple users are connected.

## Reporting a Bug

Please include:

**Bleach Resources Version:**  
**Foundry Version:**  
**D&D 5e Version:**  
**Browser:**  
**Other Enabled Modules:**  

**Character Class/Level:**  

**Feature or Item Involved:**  

**Steps to Reproduce:**

1.
2.
3.

**Expected Result:**

**Actual Result:**

**Console Errors:**

**Does the issue still occur with every module except Bleach Resources disabled?**

Yes / No / Not Tested

## Important

Please distinguish between:

- A Foundry automation bug
- A possible Soul Society 5e rules question
- A deliberate manual mechanic
- A feature that has not yet been implemented

Not every source mechanic can or should be fully automated.