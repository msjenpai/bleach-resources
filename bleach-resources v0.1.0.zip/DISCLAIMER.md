# Disclaimer

Bleach Resources is an unofficial, fan-made project created for tabletop roleplaying and Foundry Virtual Tabletop playtesting.

This project is not affiliated with, sponsored by, approved by, or endorsed by the creators, publishers, licensors, distributors, or other rights holders associated with:

- Bleach
- Dungeons & Dragons
- Foundry Virtual Tabletop
- D&D Wiki
- Soul Society 5e / Soul Society Supplement

All trademarks, characters, settings, names, artwork, game systems, and other intellectual property belonging to third parties remain the property of their respective owners.

Bleach Resources does not claim ownership of third-party intellectual property.

Unless specifically identified otherwise, artwork or other media not created for Bleach Resources should not be redistributed with this repository without permission or an appropriate license.

This repository is currently distributed as an unofficial playtest project.

For source and licensing information relating to adapted rules content, see `ATTRIBUTION.md`.